document.addEventListener("DOMContentLoaded", () => {
    const API_URL = "https://www.cbr-xml-daily.ru/daily_json.js";
    const CACHE_KEY = "konvertus-rates";

    // валюты для табло
    const BOARD = [
        ["USD", "Доллар США"],
        ["EUR", "Евро"],
        ["CNY", "Китайский юань"],
        ["GBP", "Фунт стерлингов"],
        ["CHF", "Швейцарский франк"],
        ["JPY", "Японская иена"],
        ["TRY", "Турецкая лира"],
        ["KZT", "Казахстанский тенге"]
    ];

    const title = document.getElementById("title");
    const input = document.getElementById("input");
    const output = document.getElementById("output");
    const selectTop = document.getElementById("select-top");
    const selectBottom = document.getElementById("select-bottom");
    const swap = document.getElementById("swap");
    const refresh = document.getElementById("refresh");
    const status = document.getElementById("rates-status");
    const board = document.getElementById("rates-board");

    // rates[код] = { rub: сколько рублей за 1 единицу, prev: то же на прошлую дату, nominal, value }
    let rates = null;

    function buildRates(data) {
        const result = { RUB: { rub: 1, prev: 1, nominal: 1, value: 1 } };
        for (const [code, v] of Object.entries(data.Valute)) {
            result[code] = {
                rub: v.Value / v.Nominal,
                prev: v.Previous / v.Nominal,
                nominal: v.Nominal,
                value: v.Value
            };
        }
        return result;
    }

    function calculate() {
        const val = parseFloat(input.value);
        if (isNaN(val) || !rates) {
            output.value = "";
            return;
        }

        const from = rates[selectTop.value];
        const to = rates[selectBottom.value];
        if (!from || !to) {
            output.value = "Нет курса";
            return;
        }

        const result = (val * from.rub) / to.rub;
        output.value = Number(result.toFixed(Math.abs(result) >= 1 ? 2 : 6));
    }

    function capitalize(s) {
        return s.charAt(0).toUpperCase() + s.slice(1);
    }

    function update() {
        if (title) {
            const first = selectTop.options[selectTop.selectedIndex].dataset.short;
            const second = selectBottom.options[selectBottom.selectedIndex].dataset.short;
            title.textContent = `${capitalize(first)} в ${second}`;
        }
        calculate();
    }

    function renderBoard() {
        board.textContent = "";
        for (const [code, name] of BOARD) {
            const r = rates[code];
            if (!r) continue;

            const diff = r.prev ? ((r.rub - r.prev) / r.prev) * 100 : 0;
            const dir = Math.abs(diff) < 0.005 ? "" : diff > 0 ? "up" : "down";
            const arrow = dir === "up" ? "▲" : dir === "down" ? "▼" : "•";

            const card = document.createElement("div");
            card.className = "rate-card";

            const codeEl = document.createElement("div");
            codeEl.className = "rate-code";
            codeEl.textContent = code;

            const nameEl = document.createElement("div");
            nameEl.className = "rate-name";
            nameEl.textContent = r.nominal > 1 ? `${name} (за ${r.nominal})` : name;

            const valueEl = document.createElement("div");
            valueEl.className = "rate-value";
            valueEl.textContent = r.value.toLocaleString("ru-RU", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 4
            }) + " ₽";

            const changeEl = document.createElement("div");
            changeEl.className = "rate-change " + dir;
            changeEl.textContent = `${arrow} ${diff > 0 ? "+" : ""}${diff.toFixed(2).replace(".", ",")}%`;

            card.append(codeEl, nameEl, valueEl, changeEl);
            board.append(card);
        }
    }

    function setStatus(text, isError = false) {
        status.textContent = text;
        status.classList.toggle("error", isError);
    }

    function formatDate(iso) {
        return new Date(iso).toLocaleDateString("ru-RU", { timeZone: "Europe/Moscow" });
    }

    function apply(data, stale) {
        rates = buildRates(data);
        renderBoard();
        calculate();

        let text = `Курс ЦБ РФ на ${formatDate(data.Date)}`;
        if (stale) {
            text += " · нет связи с сервером, показан сохранённый курс";
        } else {
            text += " · проверено в " + new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
        }
        setStatus(text);
    }

    function readCache() {
        try {
            return JSON.parse(localStorage.getItem(CACHE_KEY));
        } catch {
            return null;
        }
    }

    function writeCache(data) {
        try {
            localStorage.setItem(CACHE_KEY, JSON.stringify(data));
        } catch {
            // хранилище недоступно — не страшно
        }
    }

    async function load() {
        refresh.disabled = true;
        refresh.classList.add("loading");
        if (!rates) setStatus("Загружаем курс…");

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);

        try {
            const response = await fetch(API_URL, { cache: "no-store", signal: controller.signal });
            if (!response.ok) throw new Error("HTTP " + response.status);
            const data = await response.json();
            if (!data.Valute) throw new Error("Неожиданный ответ");

            writeCache(data);
            apply(data, false);
        } catch {
            const cached = readCache();
            if (cached && cached.Valute) {
                apply(cached, true);
            } else {
                setStatus("Не удалось загрузить курс. Проверьте интернет и нажмите «Обновить курс».", true);
            }
        } finally {
            clearTimeout(timer);
            refresh.disabled = false;
            refresh.classList.remove("loading");
        }
    }

    input?.addEventListener("input", calculate);
    selectTop?.addEventListener("change", update);
    selectBottom?.addEventListener("change", update);
    refresh?.addEventListener("click", load);

    swap?.addEventListener("click", () => {
        [selectTop.value, selectBottom.value] = [selectBottom.value, selectTop.value];
        update();
    });

    const copy = document.getElementById("copy");

    copy?.addEventListener("click", async () => {
        if (!output.value || isNaN(Number(output.value))) return;

        try {
            await navigator.clipboard.writeText(output.value);
        } catch {
            output.select();
            document.execCommand("copy");
        }

        const icon = copy.querySelector("span");
        icon.textContent = "check";
        setTimeout(() => (icon.textContent = "content_copy"), 1500);
    });

    update();
    load();
});
